<?php
    function obtenerConexion()
    {
        $server = 'localhost';
        $user = 'root';
        $pass = '';
        $db = 'yerblues';
        $cnx = new mysqli($server, $user, $pass, $db);
        return $cnx;
    }
    function oficinas($ofi)
    {
        $cnx = obtenerConexion();
        $st = "SELECT * FROM oficinatnt WHERE region = '$ofi' ORDER BY idoficina;";
        $res = $cnx->query($st);
        return $res;
    }
    function pesoOficina($ofi, $peso)
    {
        $cnx = obtenerConexion();
        $st = "SELECT * FROM valoresoficina WHERE idoficina = '$ofi' AND '$peso' < pesomaximo ORDER BY pesomaximo LIMIT 1;";
        $res = $cnx->query($st);
        return $res;
    }
    function filas()
    {
        $cnx = obtenerConexion();
        $st = "SELECT * FROM oficinatnt";
        $res = $cnx->query($st);
        $row_cnt = $res->num_rows;
        return $row_cnt;
    }
    function laDireccion()
    {
        $cnx = obtenerConexion();
        $st = "SELECT * FROM oficinatnt where idoficina = 0";
        $res = $cnx->query($st);
        $le = $res->fetch_assoc();
        return $le['direccion'];
    }
