<?php
namespace Impac\Tntalpha3\Model\Shipping\Source\Method;

class Oficinas
{
    public function toOptionArray()
    {
        //You can fetch them from a database, or define them here.
        $shippingRates = [
            0 => [
                'code' => 'carrier_1_code',
                'title' => 'Carrier 1 Title'
            ],
            1 => [
                'code' => 'carrier_2_code',
                'title' => 'Carrier 2 Title'
            ],
        ];
        $arr = [];
        foreach ($shippingRates as $shippingRate) {
            $arr[] = ['value' => $shippingRate['code'], 'label' => $shippingRate['title']];
        }
        return $arr;
    }
}
