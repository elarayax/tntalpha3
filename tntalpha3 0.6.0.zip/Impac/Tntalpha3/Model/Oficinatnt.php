<?php
namespace Impac\Tntalpha3\Model;

class Oficinatnt extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Impac\Tntalpha3\Model\ResourceModel\Oficinatnt');
    }
}
?>