<?php
namespace Magecomp\Customshipping\Model;

include 'conect.php';

use Magecomp\Customshipping\Helper\Data;
use Magento\Backend\App\Area\FrontNameResolver;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\State;
use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory;
use Magento\Quote\Model\Quote\Address\RateResult\MethodFactory;
use Magento\Shipping\Helper\Carrier as ShippingCarrierHelper;
use Magento\Shipping\Model\Carrier\AbstractCarrier;
use Magento\Shipping\Model\Carrier\CarrierInterface;
use Magento\Shipping\Model\Rate\ResultFactory;
use Psr\Log\LoggerInterface;

class Carrier extends AbstractCarrier implements CarrierInterface
{
    const CODE = 'customshipping';

    protected $_code = self::CODE;
    protected $_rateMethodFactory;
    protected $_carrierHelper;
    protected $_rateFactory;
    protected $_state;
    protected $_CustomshippingHelper;
    protected $_sonic;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        ErrorFactory $rateErrorFactory,
        LoggerInterface $logger,
        ResultFactory $rateFactory,
        ShippingCarrierHelper $carrierHelper,
        MethodFactory $rateMethodFactory,
        State $state,
        Data $CustomshippingHelper,
        array $data = []
    ) {
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
        $this->_scopeConfig = $scopeConfig;
        $this->_rateErrorFactory = $rateErrorFactory;
        $this->_logger = $logger;
        $this->_rateFactory = $rateFactory;
        $this->_carrierHelper = $carrierHelper;
        $this->_rateMethodFactory = $rateMethodFactory;
        $this->_state = $state;
        $this->_CustomshippingHelper = $CustomshippingHelper;
    }

    public function collectRates(RateRequest $request)
    {
        $result = $this->_rateFactory->create();
        if (!$this->getConfigFlag('active') || (!$this->isAdmin() && !$this->_CustomshippingHelper->IsCustomShippingAllowedForFrontend())) {
            return $result;
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $cart = $objectManager->get('\Magento\Checkout\Model\Cart');
        $volumetrico = 0;
        $items = $cart->getQuote()->getAllItems();
        $ciudad = $cart->getQuote()->getShippingAddress()->getRegion();
        foreach ($items as $item) {
            $elegido = 0;
            $product = $objectManager->get('Magento\Catalog\Model\Product')->load($item->getProductId());
            if ($product->getWeight() > 0) {
                if ($product->getVolumetrico() > $product->getWeight()) {
                    $elegido = $product->getVolumetrico();
                } else {
                    $elegido = $product->getWeight();
                }
                $volumetrico +=($elegido * $item->getQty());
            }
        }
        $ld = 1;
        $filas = filas();
        $filas ++;
        $regionFactory = $objectManager->get('Magento\Directory\Model\RegionFactory');
        $regionModel = $regionFactory->create();
        $shipperRegionCode = "";
        $d = $cart->getQuote()->getShippingAddress()->getRegionID();
        if (is_numeric($d)) {
            $shipperRegion = $regionFactory->create()->load($d);
            if ($shipperRegion->getId()) {
                $shipperRegionCode = $shipperRegion->getCode();
            }
        }
        $mario = oficinas($shipperRegionCode);
        while ($ld < $filas) {
            $tails = $mario->fetch_assoc();
            $s = $this->_rateMethodFactory->create();
            $s->setCarrier($this->_code);
            $s->setCarrierTitle($tails['direccion']);
            $s->setMethod($tails['nombreoficina']);
            //$tails['nombreoficina']
            $pesitos = pesoOficina($tails['idoficina'], $volumetrico);
            $pesotes = $pesitos->fetch_assoc();
            $total = 0;
            if ($pesotes['costoa']!=0) {
                $s->setPrice($pesotes['costoa']);
                $total = $pesotes['costoa'];
            } else {
                $costob = $pesotes['costob'] * $volumetrico;
                $s->setPrice($costob);
                $total = $costob;
            }
            //$tails['nombreoficina']
            $s->setMethodTitle("oficina " . $tails['nombreoficina']);
            $s->setCost(0);
            //$s->setPrice($volumetrico);
            if ($total > 0) {
                $result->append($s);
            }
            $ld++;
        }
        return $result;
    }

    public function getAllowedMethods()
    {
        return [$this->getCarrierCode() => __($this->getConfigData('name'))];
    }

    public function isTrackingAvailable()
    {
        return false;
    }

    protected function isAdmin()
    {
        return $this->_state->getAreaCode() == FrontNameResolver::AREA_CODE;
    }
}
